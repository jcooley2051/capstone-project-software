#ifndef __WIFI_TEST_H__
#define __WIFI_TEST_H__

#define EXAMPLE_MAXIMUM_RETRY 3

void init_flash();
void init_mqtt();
void init_wifi();
void config_wifi();

#endif