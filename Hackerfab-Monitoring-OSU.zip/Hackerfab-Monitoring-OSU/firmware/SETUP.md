# Instructions for setting up ESP-IDF for developing for the ESP32

VSCode:

https://github.com/espressif/vscode-esp-idf-extension/blob/master/docs/tutorial/install.md

Eclipse:

https://github.com/espressif/idf-eclipse-plugin/blob/master/README.md