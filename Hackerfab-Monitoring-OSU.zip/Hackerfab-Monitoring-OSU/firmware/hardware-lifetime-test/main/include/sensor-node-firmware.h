#ifndef SENSOR_NODE_FIRMWARE_H
#define SENSOR_NODE_FIRMWARE_H

void app_main(void);

#endif