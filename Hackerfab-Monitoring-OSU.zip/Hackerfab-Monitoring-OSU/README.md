# capstone-project-software
The software for Team 15's capstone project

Firmware folder will contain the code for:
- ESP32 sensor nodes

Software folder will contain the software for:
- Data formatting
- Data analysis
- Data logging
- The GUI display

Each project should be within its own seperate project folder that can be opened in the respective IDE. The repository is simply acting as a container for all of the projects.

Features for a program should be developed on their own respective branch and then merged into master.